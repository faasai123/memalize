# Replace the blank placeholder with a real starting page

The project currently renders the default template placeholder at `/`, which is why the preview looks blank. Nothing is broken — there is simply no page yet.

Since no specific product was named, I will build a clean, general-purpose starter page you can steer in any direction from here.

## What you get

- A polished single home page at `/` with:
  - A header with a wordmark and simple navigation
  - A hero section with headline, supporting copy, and two call-to-action buttons
  - A three-item feature row
  - A footer
- A distinctive design system (warm neutral base, one strong accent, a display/body font pairing) defined as tokens, not hardcoded colors — so restyling later is a one-file change
- Light/dark support out of the box
- Real page metadata (title, description, social preview tags) instead of "Lovable App"

## Technical notes

- Rewrite `src/routes/index.tsx`, removing the placeholder markup and adding a route-level `head()` with unique title/description/og/twitter tags
- Update `src/routes/__root.tsx` head defaults away from the template strings and add the font `<link>` tags there
- Extend the token set in `src/styles.css` (colors, fonts, radii) for both `:root` and `.dark`
- Extract page sections into small components under `src/components/`
- No backend, database, or auth is involved

## Next step

Tell me what the app is actually for (a business site, a tool, a dashboard, a personal page) and I will reshape this page around it.
