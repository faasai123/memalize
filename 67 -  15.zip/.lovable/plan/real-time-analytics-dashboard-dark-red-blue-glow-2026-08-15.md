# Real-time analytics dashboard (dark, red/blue glow)

A single-screen analytics dashboard at `/`, styled as a modern dark product UI on a gradient black-blue background with red and blue glowing accents, lit by subtle red and blue lightning-tone glints in the glow. The uploaded questionnaire (meme categories rated on happy / sad / angry / stressed / bored, 1-10) sets the content of the widgets, so the charts show something meaningful rather than placeholder data.

This pass is visual design only, using realistic mock data. No database or live survey submissions yet.

## Layout

```text
+--------------------------------------------------------------+
| top bar: "Memalize" wordmark, live badge, time pills, avatar  |
+--------------------------------------------------------------+
| metric card | metric card | metric card | metric card         |
+---------------------------------+----------------------------+
| line chart: emotion over time   | donut: category share      |
+---------------------------------+----------------------------+
| bar chart: avg emotion per meme category | live feed panel   |
+--------------------------------------------------------------+
                                   ( floating survey CTA pill ) |
```

- Metric cards: total responses, responses per minute, average happiness score, completion rate — each with a sparkline and a delta chip.
- Line chart: rolling emotion averages over the last hour, one line per emotion.
- Donut: share of responses across the 9 meme categories (Animal, Legendary, IRL, Entertainment, Text, Animation, Cursed, Brainrot, Thumbnail).
- Bar chart: average happiness per meme category, red-to-blue gradient bars.
- Side panel: latest incoming responses, streaming in.
- Floating CTA bottom-right: "Take the survey", glowing, minimal.
- Every chart card carries a title plus a smaller one-line subheading describing what the chart shows.

## Motion and feel

- Cards slide in staggered on load and lift slightly on hover.
- Soft glow rings behind key cards, hairline borders, blurred glass surfaces.
- A pulsing "Live" dot and numbers that tick periodically to convey realtime (client-side simulation).

## Technical notes

- Extend `src/styles.css`: dark-first token set (deep black-blue background, blue and red accent tokens, glow shadow tokens, gradient tokens). No hardcoded colors in components.
- Typography: a modern geometric sans for UI with tabular figures for metrics, loaded via `<link>` in `src/routes/__root.tsx`.
- Charts with Recharts (installed if absent), themed through CSS variables.
- New components under `src/components/dashboard/`: `top-bar`, `metric-card`, `emotion-trend-chart`, `category-share-chart`, `category-bar-chart`, `live-feed-panel`, `survey-cta`.
- `src/routes/index.tsx` composes the dashboard and gets its own title/description/og metadata. The existing starter components are removed.
- Mock data in `src/lib/dashboard-data.ts`, shaped to match the questionnaire so a real backend can replace it cleanly.
- Responsive: widgets stack on mobile, CTA stays pinned.

## Not in this pass

The actual survey flow (respondent info, 1-10 emotion sliders, randomized meme sets per folder) and storing real responses. The CTA links to a `/survey` route we can build next.